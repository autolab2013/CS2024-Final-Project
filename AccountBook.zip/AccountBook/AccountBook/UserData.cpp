#include "UserData.h"



UserData::UserData()
{
}


UserData::~UserData()
{
}
